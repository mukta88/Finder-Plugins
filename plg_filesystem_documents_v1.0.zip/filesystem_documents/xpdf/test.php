<?php
echo $dir_name=dirname(__FILE__).'/pdftotext-linux';
echo $command=$dir_name." -enc \"UTF-8\" -eol unix -nopgbrk ".dirname(__FILE__)."/test.pdf";
//$command="whoami";
exec($command,$op,$ret);
var_dump($op);
var_dump($ret);